	/*
	 * defines.h
	 *
	 *  Created on: 2018年4月14日
	 *      Author: o2
	 */

	#ifndef DEFINES_H_
	#define DEFINES_H_

	#ifdef STM32F40_41xxx
		#define SIGNAL_PIN_0	GPIO_Pin_0
		#define SIGNAL_PIN_1	GPIO_Pin_1
		#define SIGNAL_PIN_2	GPIO_Pin_2
		#define SIGNAL_PIN_3	GPIO_Pin_3
		#define SIGNAL_PORT		GPIOB
		#define SIGNAL_RCC		RCC_AHB1Periph_GPIOB
	#elif defined(STM32F429_439xx)
		#define SIGNAL_PIN_0	GPIO_Pin_13
		#define SIGNAL_PIN_1	GPIO_Pin_14
		//#define SIGNAL_PIN_2	GPIO_Pin_13
		//#define SIGNAL_PIN_3	GPIO_Pin_14
		#define SIGNAL_PORT		GPIOG
		#define SIGNAL_RCC		RCC_AHB1Periph_GPIOG
	#endif
		
	#endif /* DEFINES_H_ */

#ifndef __GPIO_H__
#define __GPIO_H__

void GPIO_Config(void);

#endif

/*
 * bsp.c
 *
 *  Created on: 2018年4月14日
 *      Author: o2
 */
#include "includes.h"

void BSP_Config()
{
	GPIO_Config();
}


/**
  ******************************************************************************
  * @file    Project/STM32F4xx_StdPeriph_Templates/main.c 
  * @author  MCD Application Team
  * @version V1.8.0
  * @date    04-November-2016
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2016 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "includes.h"

/** @addtogroup Template_Project
  * @{
  */ 

static void vTaskTaskUserIF(void *pvParameters);
static void vTaskLED(void *pvParameters);
static void vTaskMsgPro(void *pvParameters);
static void vTaskStart(void *pvParameters);
static void AppTaskCreate(void);


static TaskHandle_t xHandleTaskUserIF = NULL;
static TaskHandle_t xHandleTaskLED = NULL;
static TaskHandle_t xHandleTaskMsgPro = NULL;
static TaskHandle_t xHandleTaskStart = NULL;

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main(void)
{ 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
	
  __set_PRIMASK(1);

	BSP_Config();

	AppTaskCreate();

	vTaskStartScheduler();
	
  /* Infinite loop */
  while (1)
  {
		
  }
}



/*******************************************************************************
* ???  :      vTaskTaskUserIF
* ??:          ??????,????LED??
* ????:      pvParameters?????????????
*
* Output         : ?
* Return         :
*******************************************************************************/
static void vTaskTaskUserIF(void *pvParameters)
{
  while(1)
  {
    GPIO_ToggleBits(GPIOB, GPIO_Pin_0);
    vTaskDelay(100);
  }
}


static void vTaskLED(void *pvParameters)
{
  while(1)
  {
    GPIO_ToggleBits(GPIOB, GPIO_Pin_1);
    vTaskDelay(500);
  }
}


static void vTaskMsgPro(void *pvParameters)
{
  while(1)
  {
    GPIO_ToggleBits(GPIOA, GPIO_Pin_3);
    vTaskDelay(300);
  }
}


static void vTaskStart(void *pvParameters)
{
  while(1)
  {
    GPIO_ToggleBits(GPIOA, GPIO_Pin_4);
    vTaskDelay(400);
  }
}

static void AppTaskCreate(void)
{
  xTaskCreate(vTaskTaskUserIF,
              "vTaskUserIF",
              512,
              NULL,
              1,
              &xHandleTaskUserIF);

  xTaskCreate(vTaskLED,
              "vTaskLED",
              512,
              NULL,
              1,
              &xHandleTaskLED);

  xTaskCreate(vTaskMsgPro,
              "vTaskMsgPro",
              512,
              NULL,
              3,
              &xHandleTaskMsgPro);

  xTaskCreate(vTaskStart,
              "vTaskStart",
              512,
              NULL,
              4,
              &xHandleTaskStart);
}

/********************************* End of file *********************************/
